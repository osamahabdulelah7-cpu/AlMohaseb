# المحاسب — Android

تطبيق حسابات عربي بسيط، العملة فيه ريال، ويحتوي على:
- تصنيفات قابلة للتسمية والإضافة.
- حسابات داخل التصنيفات.
- إضافة معاملات (له / عليه).
- المبلغ والبيان والتاريخ.
- الرصيد التلقائي.
- كشف حساب لكل حساب.
- البحث.
- حفظ البيانات محليًا على الهاتف.

## البناء في Android Studio
افتح مجلد `AlMohasebAndroid` في Android Studio، وانتظر مزامنة Gradle، ثم:
**Build > Build APK(s)**

## البناء المجاني على GitHub
المشروع يحتوي على GitHub Actions في:
`.github/workflows/build-apk.yml`

يمكن بناء APK تلقائيًا على GitHub باستخدام Java 17 وGradle 8.7، ثم تنزيل `app-debug.apk` من قسم **Artifacts** في تشغيل الـWorkflow.

الحد الأدنى Android 6.0 (API 23)، والهدف Android 15 (API 35).
