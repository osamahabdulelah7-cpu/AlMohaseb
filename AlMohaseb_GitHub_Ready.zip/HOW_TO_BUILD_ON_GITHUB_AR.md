# طريقة بناء تطبيق «المحاسب» مجانًا عبر GitHub

هذه النسخة مجهزة للعمل مع GitHub Actions، ولا تحتاج إلى Android Studio على جهازك.

## 1) أنشئ مستودعًا جديدًا
من GitHub اختر **New repository** وأنشئ مستودعًا جديدًا، ويفضل أن يكون **Public** إذا كنت تريد استخدام GitHub Actions بدون تعقيدات في حدود الاستخدام.

## 2) ارفع ملفات المشروع
بعد فك ضغط هذا الملف، ادخل إلى مجلد `AlMohasebAndroid`.
ارفع **محتويات المجلد** إلى جذر المستودع، وليس ملف ZIP نفسه.

يجب أن ترى في جذر المستودع مثلًا:
- `build.gradle`
- `settings.gradle`
- `gradle.properties`
- مجلد `app`
- مجلد `.github`

## 3) انتظر البناء
بعد رفع الملفات سيبدأ GitHub Actions تلقائيًا عند الدفع إلى فرع `main`.

أو من تبويب **Actions** اختر:
**Build المحاسب APK → Run workflow**

## 4) تحميل APK
بعد نجاح العملية:
**Actions → Build المحاسب APK → آخر تشغيل ناجح → Artifacts → AlMohaseb-debug-apk**

نزّل الملف المضغوط وافتحه لتحصل على:
`app-debug.apk`

هذا APK تجريبي (Debug) ويمكن تثبيته على هاتف أندرويد.
