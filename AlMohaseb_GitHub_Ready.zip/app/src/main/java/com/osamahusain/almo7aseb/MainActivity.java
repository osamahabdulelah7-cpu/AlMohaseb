package com.osamahusain.almo7aseb;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int CYAN=Color.rgb(8,169,220), BG=Color.rgb(238,245,248);
    LinearLayout root, content; TextView title, total; EditText search;
    ArrayList<Account> accounts=new ArrayList<>(); ArrayList<Tx> txs=new ArrayList<>();
    ArrayList<String> cats=new ArrayList<>();
    android.content.SharedPreferences sp;

    public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("db",0); load(); home();}

    void base(String t){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(12,0,12,0); bar.setBackgroundColor(CYAN);
        TextView menu=tv("☰",27,Color.WHITE); menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v->drawer());
        title=tv(t,19,Color.WHITE); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,58,1); tp.setMargins(14,0,0,0); bar.addView(menu,new LinearLayout.LayoutParams(35,58)); bar.addView(title,tp);
        TextView dots=tv("⋮",28,Color.WHITE); bar.addView(dots,new LinearLayout.LayoutParams(35,58));
        root.addView(bar,new LinearLayout.LayoutParams(-1,58));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(8,8,8,80);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(Color.WHITE);
        String[] ns={"⌂\nالحسابات","☷\nالتصنيفات","＋\nمعاملة","👤\nحساب"};
        Runnable[] rs={this::home,this::categories,this::transaction,this::accountForm};
        for(int i=0;i<4;i++){final int j=i; Button q=new Button(this); q.setText(ns[i]);q.setTextSize(11);q.setTextColor(Color.DKGRAY);q.setBackgroundColor(Color.WHITE);q.setOnClickListener(v->rs[j].run());nav.addView(q,new LinearLayout.LayoutParams(0,56,1));}
        root.addView(nav,new LinearLayout.LayoutParams(-1,56)); setContentView(root);
    }

    TextView tv(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    GradientDrawable bg(int c){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(9);return g;}
    TextView card(String name,String amount,int num,View.OnClickListener click){
        LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(8,7,7,7);box.setBackground(bg(Color.WHITE));box.setElevation(3);
        TextView ico=tv("⌄",19,Color.WHITE);ico.setGravity(Gravity.CENTER);ico.setBackground(bg(Color.rgb(180,75,66)));box.addView(ico,new LinearLayout.LayoutParams(39,39));
        TextView n=tv(name+"\n"+amount,14,Color.DKGRAY);n.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,66,1);np.setMargins(8,0,0,0);box.addView(n,np);
        TextView badge=tv(""+num,11,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(CYAN));box.addView(badge,new LinearLayout.LayoutParams(29,35));
        box.setOnClickListener(click); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,66);p.setMargins(3,7,3,0);content.addView(box,p); return n;
    }

    void home(){
        base("الحسابات");
        search=new EditText(this);search.setHint("بحث عن حساب...");search.setSingleLine();search.setVisibility(View.GONE);content.addView(search,new LinearLayout.LayoutParams(-1,48));
        TextView c=tv("("+accounts.size()+") حساب",13,Color.rgb(37,138,169));c.setGravity(Gravity.RIGHT);content.addView(c,new LinearLayout.LayoutParams(-1,35));
        TextView find=tv("⌕",25,Color.WHITE);find.setGravity(Gravity.CENTER);find.setBackground(bg(CYAN));find.setOnClickListener(v->{search.setVisibility(search.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);search.requestFocus();});
        // account cards
        renderAccounts();
        Button add=new Button(this);add.setText("＋");add.setTextSize(28);add.setTextColor(Color.WHITE);add.setBackground(bg(CYAN));add.setOnClickListener(v->transaction());
        root.addView(add,new LinearLayout.LayoutParams(60,60));
        updateTotal();
    }
    void renderAccounts(){
        for(int i=0;i<accounts.size();i++){final Account a=accounts.get(i); if(search!=null && search.getText().length()>0 && !a.name.contains(search.getText().toString()))continue; card(a.name,money(balance(a.id)),i+1,v->statement(a));}
    }
    void updateTotal(){
        double p=0,n=0;for(Account a:accounts){double b=balance(a.id);if(b>=0)p+=b;else n-=b;}
        total=tv("عليه: "+money(n)+"     له: "+money(p)+"\nالرصيد: "+money(p-n),12,Color.DKGRAY);total.setGravity(Gravity.CENTER);total.setBackground(bg(Color.rgb(203,217,223)));
        root.addView(total,new LinearLayout.LayoutParams(-1,52));
    }

    void categories(){
        base("إدارة التصنيفات");
        for(String c:cats){LinearLayout x=new LinearLayout(this);x.setGravity(Gravity.CENTER_VERTICAL);x.setPadding(16,0,16,0);x.setBackground(bg(Color.WHITE));
            TextView n=tv(c,18,Color.DKGRAY);x.addView(n,new LinearLayout.LayoutParams(0,68,1));TextView num=tv(""+countCat(c),15,Color.DKGRAY);num.setGravity(Gravity.CENTER);x.addView(num,new LinearLayout.LayoutParams(50,68));
            x.setOnClickListener(v->categoryAccounts(c));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,68);p.setMargins(3,7,3,0);content.addView(x,p);}
        Button add=new Button(this);add.setText("＋ إضافة تصنيف");add.setTextColor(Color.WHITE);add.setBackground(bg(CYAN));add.setOnClickListener(v->addCategory());content.addView(add,new LinearLayout.LayoutParams(-1,55));
    }
    int countCat(String c){int n=0;for(Account a:accounts)if(a.cat.equals(c))n++;return n;}
    void addCategory(){final EditText e=new EditText(this);e.setHint("اسم التصنيف");new AlertDialog.Builder(this).setTitle("تصنيف جديد").setView(e).setPositiveButton("حفظ",(d,w)->{if(e.getText().length()>0){cats.add(e.getText().toString());save();categories();}}).setNegativeButton("إلغاء",null).show();}
    void categoryAccounts(String c){base(c);for(Account a:accounts)if(a.cat.equals(c))card(a.name,money(balance(a.id)),0,v->statement(a));}

    void accountForm(){
        base("حساب جديد"); final EditText name=new EditText(this);name.setHint("اسم الحساب");content.addView(name);
        final EditText phone=new EditText(this);phone.setHint("رقم الهاتف (اختياري)");content.addView(phone);
        final Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));content.addView(s);
        Button b=new Button(this);b.setText("حفظ الحساب");b.setTextColor(Color.WHITE);b.setBackground(bg(CYAN));content.addView(b);
        b.setOnClickListener(v->{if(name.getText().length()==0){toast("اكتب اسم الحساب");return;}Account a=new Account();a.id=System.currentTimeMillis();a.name=name.getText().toString();a.phone=phone.getText().toString();a.cat=cats.get(s.getSelectedItemPosition());accounts.add(a);save();home();});
    }

    void transaction(){
        base("إضافة معاملة"); Spinner s=new Spinner(this);ArrayList<String> names=new ArrayList<>();for(Account a:accounts)names.add(a.name);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));content.addView(s);
        LinearLayout seg=new LinearLayout(this);Button plus=new Button(this);plus.setText("له");Button minus=new Button(this);minus.setText("عليه");seg.addView(plus,new LinearLayout.LayoutParams(0,50,1));seg.addView(minus,new LinearLayout.LayoutParams(0,50,1));content.addView(seg);
        final int[] dir={1};plus.setOnClickListener(v->dir[0]=1);minus.setOnClickListener(v->dir[0]=-1);
        EditText amount=new EditText(this);amount.setHint("المبلغ");amount.setInputType(2|8192);content.addView(amount);
        EditText note=new EditText(this);note.setHint("البيان");content.addView(note);
        EditText date=new EditText(this);date.setHint("التاريخ");date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));content.addView(date);
        Button b=new Button(this);b.setText("حفظ المعاملة");b.setTextColor(Color.WHITE);b.setBackground(bg(CYAN));content.addView(b);
        b.setOnClickListener(v->{if(accounts.size()==0||amount.getText().length()==0){toast("أضف حسابًا وأدخل المبلغ");return;}Tx t=new Tx();t.id=System.currentTimeMillis();t.accountId=accounts.get(s.getSelectedItemPosition()).id;t.amount=Double.parseDouble(amount.getText().toString());t.dir=dir[0];t.note=note.getText().toString();t.date=date.getText().toString();txs.add(t);save();home();});
    }

    void statement(Account a){
        base(a.name);TextView head=tv("كشف حساب\nالرصيد الحالي: "+money(balance(a.id)),17,Color.DKGRAY);head.setPadding(10,10,10,10);content.addView(head,new LinearLayout.LayoutParams(-1,75));
        LinearLayout table=new LinearLayout(this);table.setOrientation(LinearLayout.VERTICAL);table.setBackground(bg(Color.WHITE));
        LinearLayout h=new LinearLayout(this);h.setBackground(bg(CYAN));for(String z:new String[]{"التاريخ / البيان","المبلغ","الرصيد"}){TextView q=tv(z,11,Color.WHITE);q.setGravity(Gravity.CENTER);h.addView(q,new LinearLayout.LayoutParams(0,45,1));}table.addView(h);
        double run=0;for(Tx t:txs)if(t.accountId==a.id){run+=t.amount*t.dir;LinearLayout r=new LinearLayout(this);TextView d=tv(t.date+"\n"+t.note,10,Color.DKGRAY);TextView am=tv(money(t.amount),10,Color.DKGRAY);TextView ba=tv(money(run),10,Color.DKGRAY);d.setPadding(4,4,4,4);r.addView(d,new LinearLayout.LayoutParams(0,58,1.2f));r.addView(am,new LinearLayout.LayoutParams(0,58,.8f));r.addView(ba,new LinearLayout.LayoutParams(0,58,1.2f));table.addView(r);}content.addView(table);
    }

    double balance(long id){double b=0;for(Tx t:txs)if(t.accountId==id)b+=t.amount*t.dir;return b;}
    String money(double x){return String.format(Locale.US,"%,.2f ريال",x);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void drawer(){final String[] items={"الحسابات","التصنيفات","إضافة معاملة","حساب جديد"};new AlertDialog.Builder(this).setTitle("المحاسب").setItems(items,(d,w)->{if(w==0)home();if(w==1)categories();if(w==2)transaction();if(w==3)accountForm();}).show();}
    void save(){StringBuilder A=new StringBuilder();for(Account a:accounts)A.append(a.id).append("|").append(esc(a.name)).append("|").append(esc(a.phone)).append("|").append(esc(a.cat)).append("\n");StringBuilder T=new StringBuilder();for(Tx t:txs)T.append(t.id).append("|").append(t.accountId).append("|").append(t.amount).append("|").append(t.dir).append("|").append(esc(t.note)).append("|").append(esc(t.date)).append("\n");StringBuilder C=new StringBuilder();for(String c:cats)C.append(esc(c)).append("\n");sp.edit().putString("a",A.toString()).putString("t",T.toString()).putString("c",C.toString()).apply();}
    void load(){String c=sp.getString("c","عام\nالبقالات\nالعائلة\nمنوع\nحساب شبكة غزة\n");for(String x:c.split("\n"))if(!x.isEmpty())cats.add(unesc(x));String a=sp.getString("a","");for(String l:a.split("\n")){if(l.isEmpty())continue;String[] p=l.split("\\|",-1);Account q=new Account();q.id=Long.parseLong(p[0]);q.name=unesc(p[1]);q.phone=unesc(p[2]);q.cat=unesc(p[3]);accounts.add(q);}String t=sp.getString("t","");for(String l:t.split("\n")){if(l.isEmpty())continue;String[] p=l.split("\\|",-1);Tx q=new Tx();q.id=Long.parseLong(p[0]);q.accountId=Long.parseLong(p[1]);q.amount=Double.parseDouble(p[2]);q.dir=Integer.parseInt(p[3]);q.note=unesc(p[4]);q.date=unesc(p[5]);txs.add(q);}}
    String esc(String s){return s.replace("\\","\\\\").replace("|","\\p").replace("\n","\\n");}
    String unesc(String s){return s.replace("\\n","\n").replace("\\p","|").replace("\\\\","\\");}
    static class Account{long id;String name="",phone="",cat="عام";}
    static class Tx{long id,accountId;double amount;int dir;String note="",date="";}
}
